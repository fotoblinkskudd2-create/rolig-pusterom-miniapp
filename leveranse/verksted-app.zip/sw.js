// Generert av scripts/build-sw.mjs – ikke rediger.
const CACHE = 'verksted-bc47a4a490';
const PRECACHE = ["./","./apps/abo-liket/","./apps/brunstoy/","./apps/doom-brems/","./apps/dump/","./apps/karantene/","./apps/kvitt/","./apps/snoball/","./apps/splitt/","./apps/stromvakt/","./apps/systemtavla/","./apps/abo-liket/index.html","./apps/abo-liket/manifest.webmanifest","./apps/brunstoy/index.html","./apps/brunstoy/manifest.webmanifest","./apps/doom-brems/index.html","./apps/doom-brems/manifest.webmanifest","./apps/dump/index.html","./apps/dump/manifest.webmanifest","./apps/karantene/index.html","./apps/karantene/manifest.webmanifest","./apps/kvitt/index.html","./apps/kvitt/manifest.webmanifest","./apps/snoball/index.html","./apps/snoball/manifest.webmanifest","./apps/splitt/index.html","./apps/splitt/manifest.webmanifest","./apps/stromvakt/index.html","./apps/stromvakt/manifest.webmanifest","./apps/systemtavla/index.html","./apps/systemtavla/manifest.webmanifest","./assets/abo-liket-BfDlCkg7.js","./assets/brunstoy-BjXsQcqL.js","./assets/doom-brems-BjajRDgv.js","./assets/dump-CxzDTVhz.js","./assets/hub-D9ENHHNu.js","./assets/karantene-iP-QY6_w.js","./assets/kvitt-Bo9eW0Zv.js","./assets/snoball-BEs8WHaq.js","./assets/splitt-jLyCJe6d.js","./assets/stromvakt-DwoiVtCw.js","./assets/systemtavla-CiKErE2G.js","./assets/ui-CIy9CPCD.css","./assets/ui-KFrxotFT.js","./icons/abo-liket-180.png","./icons/abo-liket-192.png","./icons/abo-liket-512.png","./icons/brunstoy-180.png","./icons/brunstoy-192.png","./icons/brunstoy-512.png","./icons/doom-brems-180.png","./icons/doom-brems-192.png","./icons/doom-brems-512.png","./icons/dump-180.png","./icons/dump-192.png","./icons/dump-512.png","./icons/hub-180.png","./icons/hub-192.png","./icons/hub-512.png","./icons/karantene-180.png","./icons/karantene-192.png","./icons/karantene-512.png","./icons/kvitt-180.png","./icons/kvitt-192.png","./icons/kvitt-512.png","./icons/snoball-180.png","./icons/snoball-192.png","./icons/snoball-512.png","./icons/splitt-180.png","./icons/splitt-192.png","./icons/splitt-512.png","./icons/stromvakt-180.png","./icons/stromvakt-192.png","./icons/stromvakt-512.png","./icons/systemtavla-180.png","./icons/systemtavla-192.png","./icons/systemtavla-512.png","./index.html","./manifest.webmanifest"];
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(PRECACHE)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.origin !== location.origin) return; // eksterne API-er (strømpris) går rett på nett
  e.respondWith(
    caches.match(e.request, { ignoreSearch: true }).then((hit) => hit || fetch(e.request).then((res) => {
      if (res.ok) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(e.request, copy)); }
      return res;
    }).catch(() => caches.match(new URL('./index.html', e.request.url).href)))
  );
});
