// Generert av scripts/gen-sw.mjs – ikke rediger.
const CACHE = 'vibe10-fd730a4cea'
const PRECACHE = ["./apps/brems/icon-180.png","./apps/brems/icon-192.png","./apps/brems/icon-512.png","./apps/brems/index.html","./apps/brems/manifest.webmanifest","./apps/doom/icon-180.png","./apps/doom/icon-192.png","./apps/doom/icon-512.png","./apps/doom/index.html","./apps/doom/manifest.webmanifest","./apps/garanti/icon-180.png","./apps/garanti/icon-192.png","./apps/garanti/icon-512.png","./apps/garanti/index.html","./apps/garanti/manifest.webmanifest","./apps/gjeld/icon-180.png","./apps/gjeld/icon-192.png","./apps/gjeld/icon-512.png","./apps/gjeld/index.html","./apps/gjeld/manifest.webmanifest","./apps/kjokken/icon-180.png","./apps/kjokken/icon-192.png","./apps/kjokken/icon-512.png","./apps/kjokken/index.html","./apps/kjokken/manifest.webmanifest","./apps/minnehull/icon-180.png","./apps/minnehull/icon-192.png","./apps/minnehull/icon-512.png","./apps/minnehull/index.html","./apps/minnehull/manifest.webmanifest","./apps/provefella/icon-180.png","./apps/provefella/icon-192.png","./apps/provefella/icon-512.png","./apps/provefella/index.html","./apps/provefella/manifest.webmanifest","./apps/skjold/icon-180.png","./apps/skjold/icon-192.png","./apps/skjold/icon-512.png","./apps/skjold/index.html","./apps/skjold/manifest.webmanifest","./apps/spleis/icon-180.png","./apps/spleis/icon-192.png","./apps/spleis/icon-512.png","./apps/spleis/index.html","./apps/spleis/manifest.webmanifest","./apps/start/icon-180.png","./apps/start/icon-192.png","./apps/start/icon-512.png","./apps/start/index.html","./apps/start/manifest.webmanifest","./assets/brems-CBkPZYQL.js","./assets/doom-COcY7MAW.js","./assets/format-xrVwOXJ9.js","./assets/garanti-IKL0rEUf.js","./assets/gjeld-BEEKDeju.js","./assets/hub-DYpAnLFh.js","./assets/ics-DAIP_zmw.js","./assets/kjokken-WMMB1RYx.js","./assets/minnehull-BtoYSGaJ.js","./assets/provefella-G3plfmfP.js","./assets/skjold-DIRoowEA.js","./assets/spleis-DA24PiQJ.js","./assets/start-7x-W8VMF.js","./assets/ui-btQNowhi.css","./assets/ui-iw0s3ns7.js","./icon-180.png","./icon-192.png","./icon-512.png","./index.html","./manifest.webmanifest","./apps/brems/","./apps/doom/","./apps/garanti/","./apps/gjeld/","./apps/kjokken/","./apps/minnehull/","./apps/provefella/","./apps/skjold/","./apps/spleis/","./apps/start/","./"]

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(PRECACHE)).then(() => self.skipWaiting()))
})

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  )
})

self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET' || new URL(e.request.url).origin !== location.origin) return
  e.respondWith(
    caches.match(e.request, { ignoreSearch: true }).then((hit) => hit || fetch(e.request).then((res) => {
      const copy = res.clone()
      if (res.ok) caches.open(CACHE).then((c) => c.put(e.request, copy))
      return res
    }).catch(() => caches.match('./index.html'))),
  )
})
